


public class Apple implements Fruit {

	@Override
	final public void cut() {
		System.out.println("cutting apple...");
	}

	@Override
	public void makeJuice() {

		System.out.println("making apple juice... ");
	}

}