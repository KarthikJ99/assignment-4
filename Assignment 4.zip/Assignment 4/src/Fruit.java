/**
 * Fruit
 */


public interface Fruit {	
	public static final int count = 0;
	
	// abstract methods
	void cut();
	
	void makeJuice();

    

}
